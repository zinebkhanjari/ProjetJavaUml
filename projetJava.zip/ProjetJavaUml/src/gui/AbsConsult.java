package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Dao.ConnectionDataBase;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AbsConsult extends JFrame {

	private JPanel contentPane;
	private JTable table;
private String id;
Connection conx;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AbsConsult frame = new AbsConsult();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AbsConsult() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100,774,651);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\lplpppe.PNG"));
		lblNewLabel.setBounds(248, -14, 280, 263);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 247, 728, 337);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"actualiser pour voir vos absences"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 java.sql.PreparedStatement stmt=null;
				    ResultSet result=null;
					try {
						stmt=conx.prepareStatement("select * from absence where nomAd=?");
						stmt.setString(1, id);
						result=stmt.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(result));
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					finally {
						try {
							stmt.close();
						} catch (SQLException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
					}
				
				
			}
		});
		button.setBackground(Color.WHITE);
		button.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGqqqqqqq.PNG"));
		button.setBounds(695, 204, 53, 45);
		contentPane.add(button);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdherentMenu ad=new AdherentMenu();
				ad.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\backkk.PNG"));
		btnNewButton.setBounds(20, 215, 53, 34);
		contentPane.add(btnNewButton);
	}
	public AbsConsult(String id) throws HeadlessException {
		super();

		this.id = id;
		try {
			conx=ConnectionDataBase.connectionBd();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,774,651);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\lplpppe.PNG"));
		lblNewLabel.setBounds(248, -14, 280, 263);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 247, 728, 337);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"actualiser pour voir vos absences"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 java.sql.PreparedStatement stmt=null;
				    ResultSet result=null;
					try {
						stmt=conx.prepareStatement("select * from absence where nomAd=?");
						stmt.setString(1, id);
						result=stmt.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(result));
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					finally {
						try {
							stmt.close();
						} catch (SQLException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
					}
				
				
			}
		});
		button.setBackground(Color.WHITE);
		button.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGqqqqqqq.PNG"));
		button.setBounds(695, 204, 53, 45);
		contentPane.add(button);
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdherentMenu am=new AdherentMenu();
				am.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\backkk.PNG"));
		btnNewButton.setBounds(20, 215, 53, 34);
		contentPane.add(btnNewButton);
	                   
	
}}


