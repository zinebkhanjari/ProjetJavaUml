package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Dao.ConnectionDataBase;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Dao.ConnectionDataBase;
import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Event extends JFrame {

	private JPanel contentPane;
	private JTextField nomEvField;
	private JTextField dateEvField;
	private JTextField desField;
String id;
	private Connection conx;

	

	/**
	 * Create the frame.
	 */
	public Event() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,774,651);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
		label.setBounds(327, 54, 128, 106);
		contentPane.add(label);
		try {
			conx=ConnectionDataBase.connectionBd();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		nomEvField = new JTextField();
		nomEvField.setBackground(Color.CYAN);
		nomEvField.setBounds(290, 213, 182, 20);
		contentPane.add(nomEvField);
		nomEvField.setColumns(10);
		
		dateEvField = new JTextField();
		dateEvField.setBackground(Color.CYAN);
		dateEvField.setColumns(10);
		dateEvField.setBounds(290, 259, 182, 20);
		contentPane.add(dateEvField);
		
		desField = new JTextField();
		desField.setBackground(Color.CYAN);
		desField.setColumns(10);
		desField.setBounds(290, 433, 182, 116);
		contentPane.add(desField);
		
		JPanel panel = new JPanel();
		panel.setBounds(290, 312, 182, 106);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel label_1 = new JLabel("");
		panel.add(label_1);
		
		JButton btnOk = new JButton("");
		btnOk.setBackground(Color.WHITE);
		btnOk.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\voir.PNG"));
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateData();
				/*ResultSet result=null;
				PreparedStatement stmt=null;
			try {
				//int idd=Integer.parseInt(id);
				
				stmt=conx.prepareStatement("select nomEv,dateEv,description,affiche from events where nomEv=?");
				
			//	System.out.println("thusus"+idd);
				stmt.setString(1, id);
				 result=stmt.executeQuery();
				while(result.next())
				{ String nom=result.getString("nomEv").toString();
					nomEvField.setText(nom);
					desField.setText(result.getString("description"));
					dateEvField.setText((result.getString("dateEv")));
					byte[] img=result.getBytes("affiche");
					ImageIcon image=new ImageIcon(img);
					Image imgg=image.getImage();
					Image  lastImg=imgg.getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
					ImageIcon iimg=new ImageIcon(lastImg);
					label_1.setIcon(iimg);
					}
			} 
			catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
			
			}
		});
		btnOk.setBounds(487, 213, 60, 58);
		contentPane.add(btnOk);
		
		JLabel lblNomDeLevenement = new JLabel("nom de l'\u00E9venement:");
		lblNomDeLevenement.setBounds(83, 208, 170, 31);
		contentPane.add(lblNomDeLevenement);
		
		JLabel lblAfficheDeLvenement = new JLabel("affiche de l'\u00E9venement:");
		lblAfficheDeLvenement.setBounds(83, 312, 170, 31);
		contentPane.add(lblAfficheDeLvenement);
		
		JLabel lblDateDeLvenement = new JLabel("date de l'\u00E9venement :");
		lblDateDeLvenement.setBounds(83, 254, 170, 31);
		contentPane.add(lblDateDeLvenement);
		
		JLabel lblDesciptionDeLevenement = new JLabel("desciption de l'evenement:");
		lblDesciptionDeLevenement.setBounds(83, 433, 170, 31);
		contentPane.add(lblDesciptionDeLevenement);
		
		JLabel lblVoirLevenement = new JLabel("voir l'evenement ");
		lblVoirLevenement.setBounds(497, 282, 100, 14);
		contentPane.add(lblVoirLevenement);
		
		JButton btnOk_1 = new JButton("ok");
		btnOk_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnOk_1.setBounds(347, 578, 89, 23);
		contentPane.add(btnOk_1);
		
	}
public Event(String id) throws HeadlessException {
	super();
	
	
	try {
		conx=ConnectionDataBase.connectionBd();
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setBounds(100, 100,774,651);
	contentPane = new JPanel();
	contentPane.setBackground(Color.WHITE);
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(contentPane);
	contentPane.setLayout(null);
	
	JLabel label = new JLabel("");
	label.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
	label.setBounds(327, 54, 128, 106);
	contentPane.add(label);
	
	nomEvField = new JTextField();
	nomEvField.setBackground(Color.CYAN);
	nomEvField.setBounds(290, 213, 182, 20);
	contentPane.add(nomEvField);
	nomEvField.setColumns(10);
	
	dateEvField = new JTextField();
	dateEvField.setBackground(Color.CYAN);
	dateEvField.setColumns(10);
	dateEvField.setBounds(290, 259, 182, 20);
	contentPane.add(dateEvField);
	
	desField = new JTextField();
	desField.setBackground(Color.CYAN);
	desField.setColumns(10);
	desField.setBounds(290, 433, 182, 116);
	contentPane.add(desField);
	
	JPanel panel = new JPanel();
	panel.setBounds(290, 312, 182, 106);
	contentPane.add(panel);
	panel.setLayout(new GridLayout(0, 1, 0, 0));
	
	JLabel label_1 = new JLabel("");
	panel.add(label_1);
	
	

	JButton btnOk_1 = new JButton("ok");
	btnOk_1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	});
	btnOk_1.setBounds(347, 578, 89, 23);
	contentPane.add(btnOk_1);
	
	JLabel lblNomDeLevenement = new JLabel("nom de l'\u00E9venement:");
	lblNomDeLevenement.setBounds(83, 208, 115, 31);
	contentPane.add(lblNomDeLevenement);
	
	JLabel lblAfficheDeLvenement = new JLabel("affiche de l'\u00E9venement:");
	lblAfficheDeLvenement.setBounds(83, 312, 115, 31);
	contentPane.add(lblAfficheDeLvenement);
	
	JLabel lblDateDeLvenement = new JLabel("date de l'\u00E9venement :");
	lblDateDeLvenement.setBounds(83, 254, 115, 31);
	contentPane.add(lblDateDeLvenement);
	
	JLabel lblDesciptionDeLevenement = new JLabel("desciption de l'evenement:");
	lblDesciptionDeLevenement.setBounds(83, 433, 115, 31);
	contentPane.add(lblDesciptionDeLevenement);
	JButton btnOk = new JButton("");
	btnOk.setBackground(Color.WHITE);
	btnOk.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\voir.PNG"));
	btnOk.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			updateData();
			/*ResultSet result=null;
			PreparedStatement stmt=null;
		try {
			//int idd=Integer.parseInt(id);
			
			stmt=conx.prepareStatement("select nomEv,dateEv,description,affiche from events where nomEv=?");
			
		//	System.out.println("thusus"+idd);
			stmt.setString(1, id);
			 result=stmt.executeQuery();
			while(result.next())
			{ String nom=result.getString("nomEv").toString();
				nomEvField.setText(nom);
				desField.setText(result.getString("description"));
				dateEvField.setText((result.getString("dateEv")));
				byte[] img=result.getBytes("affiche");
				ImageIcon image=new ImageIcon(img);
				Image imgg=image.getImage();
				Image  lastImg=imgg.getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
				ImageIcon iimg=new ImageIcon(lastImg);
				label_1.setIcon(iimg);
				}
		} 
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		}
	});
	btnOk.setBounds(487, 213, 60, 58);
	contentPane.add(btnOk);
	

	btnOk.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			updateData();
			}});

	this.id=id;
	System.out.println("this is id in construct"+id);
}



/**
 * Launch the application.
 */
public static void main(String[] args) {
	EventQueue.invokeLater(new Runnable() {
		public void run() {
			try {
				Event frame = new Event();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});
}
public void updateData() {
	PreparedStatement stmt=null;
	ResultSet result=null;
	
	
	try {
		stmt=conx.prepareStatement("select nomEv,dateEv,description,affiche from events where idEv=?");
		//int idd=Integer.parseInt(id);
		stmt.setString(1, id);
		result=stmt.executeQuery();
		while(result.next()) {
			String nom=result.getString("nomEv").toString();
			String date=result.getString("dateEv").toString();
			String des=result.getString("description").toString();
			
			/*byte[] img=result.getBytes("affiche");
			ImageIcon image=new ImageIcon(img);
			Image imgg=image.getImage();
			Image  lastImg=imgg.getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iimg=new ImageIcon(lastImg);
			label_1.setIcon(iimg);*/
			
			nomEvField.setText(nom);
			dateEvField.setText(date);
			desField.setText(des);
			dateEvField.setEditable(false);
			
			
			
			
			
		}
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	   
}
}