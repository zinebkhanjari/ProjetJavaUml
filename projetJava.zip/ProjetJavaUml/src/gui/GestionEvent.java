package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

import com.mysql.jdbc.Blob;
import com.mysql.jdbc.Connection;

import com.toedter.calendar.JDateChooser;

import Dao.ConnectionDataBase;
//import jdk.jfr.internal.cmd.Execute;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GestionEvent extends JFrame {

	private JPanel contentPane;
	private JTextField nomEvField;
	private JTextField desField;
	private JTable table;
	java.sql.Connection conx;
	String pathh;
	JLabel label_1;
	JPanel panel;
	private JTextField dateField;
	/**
	 * Launch the application.
	 */
	public void close() {
		dispose();
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionEvent frame = new GestionEvent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionEvent() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100,774,651);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
		label.setBounds(373, 11, 116, 134);
		contentPane.add(label);
		
		nomEvField = new JTextField();
		nomEvField.setBackground(Color.WHITE);
		nomEvField.setBounds(122, 103, 198, 20);
		contentPane.add(nomEvField);
		nomEvField.setColumns(10);
		
		desField = new JTextField();
		desField.setColumns(10);
		desField.setBackground(Color.WHITE);
		desField.setBounds(122, 345, 198, 112);
		contentPane.add(desField);
		try {
			conx=ConnectionDataBase.connectionBd();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JLabel lblNomDeLevenement = new JLabel("nom de l'evenement:");
		lblNomDeLevenement.setBounds(10, 106, 136, 14);
		contentPane.add(lblNomDeLevenement);
		
		JLabel lblDescription = new JLabel("Description  :");
		lblDescription.setBounds(10, 346, 146, 14);
		contentPane.add(lblDescription);
		
		JLabel lblDate = new JLabel("date:");
		lblDate.setBounds(10, 157, 48, 14);
		contentPane.add(lblDate);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String 	nom=nomEvField.getText();
			String description=desField.getText();
			String date=dateField.getText();
			PreparedStatement stmt=null;
			InputStream imgg=null;
			try {
				imgg = new FileInputStream(new File(pathh));
			} catch (FileNotFoundException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			try {
				stmt=conx.prepareStatement("insert into events(nomEv,dateEv,description,affiche)values(?, ?, ?, ?)");
				stmt.setString(1, nom);
				stmt.setString(3, description);
				stmt.setString(2, date);
				stmt.setBlob(4, imgg);
				stmt.executeUpdate();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			
			}
			finally {
				try {
					stmt.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Ajout reussite");
				actualiserTable();
				nomEvField.setText("");
				desField.setText("");
				dateField.setText("");
				label_1.setIcon(null);}
			}
		});
		button.setBackground(Color.WHITE);
		button.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\addd.PNG"));
		button.setBounds(54, 502, 56, 53);
		contentPane.add(button);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				int j=JOptionPane.showConfirmDialog(null, "Vous voullez supprimer cette absence ?","supprimer absence",JOptionPane.YES_NO_OPTION);
				
				
				if(j==0) {
				int row=table.getSelectedRow();
				String id=table.getModel().getValueAt(row, 0).toString();
				PreparedStatement stmt=null;
				try {
					stmt=conx.prepareStatement("delete from events where idEv=?");
					stmt.setString(1, id);
					stmt.executeUpdate();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
				JOptionPane.showMessageDialog(null, "supression reussite");
				actualiserTable();
				nomEvField.setText("");
				desField.setText("");
				dateField.setText("");
				label_1.setIcon(null);
			}}
		});
		button_1.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\poubil.PNG"));
		button_1.setBackground(Color.WHITE);
		button_1.setBounds(163, 502, 56, 53);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String 	nom=nomEvField.getText();
				String description=desField.getText();
				String date=dateField.getText();
				PreparedStatement stmt=null;
				InputStream imgg=null;
				int row=table.getSelectedRow();
				String id=table.getModel().getValueAt(row, 0).toString();
				try {
					imgg = new FileInputStream(new File(pathh));
				} catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				try {
					stmt=conx.prepareStatement("update events set nomEv=?,dateEv=?,description=?,affiche=? where idEv=?");
					stmt.setString(5, id);
					stmt.setString(1, nom);
					stmt.setBlob(4, imgg);
					stmt.setString(3, description);
					stmt.setString(2, date);
					
					stmt.executeUpdate();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
				JOptionPane.showMessageDialog(null, "modification reussite");
				actualiserTable();
				nomEvField.setText("");
				desField.setText("");
				dateField.setText("");
				label_1.setIcon(null);
			}
		});
		button_2.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGjjjj.PNG"));
		button_2.setBounds(264, 502, 56, 53);
		contentPane.add(button_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(361, 199, 387, 356);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row=table.getSelectedRow();
				String id=table.getModel().getValueAt(row, 0).toString();
				PreparedStatement stmt=null;
				try {
					stmt=conx.prepareStatement("select nomEv,dateEv,description,affiche from events where idEv=?");
					stmt.setString(1, id);
					ResultSet result=stmt.executeQuery();
					while(result.next())
					{
						nomEvField.setText(result.getString("nomEv"));
						desField.setText(result.getString("description"));
						dateField.setText((result.getString("dateEv")));
						/*byte[] img=result.getBytes("affiche");
						ImageIcon image=new ImageIcon(img);
						Image imgg=image.getImage();
						Image  lastImg=imgg.getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
						ImageIcon iimg=new ImageIcon(lastImg);
						label_1.setIcon(iimg);*/
						}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"actualiser pour voir les evenements"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton button_3 = new JButton("");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actualiserTable();
			}
		});
		button_3.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGqqqqqqq.PNG"));
		button_3.setBounds(714, 157, 34, 43);
		contentPane.add(button_3);
		
		panel = new JPanel();
		panel.setBackground(Color.CYAN);
		panel.setBounds(122, 213, 163, 112);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(1, 1));
		
		 label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			
			
		});
		label_1.setBackground(Color.WHITE);
		panel.add(label_1);
		
		JButton button_4 = new JButton("");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser file=new JFileChooser();
				FileNameExtensionFilter filtre=new FileNameExtensionFilter("image","jpg","jpeg","gif","png");
				file.addChoosableFileFilter(filtre);
				int result=file.showSaveDialog(null);
				if(result==JFileChooser.APPROVE_OPTION) {
					File selectedFile=file.getSelectedFile();
					String path=selectedFile.getAbsolutePath();
					ImageIcon myImage=new ImageIcon(path);
					Image img=myImage.getImage();
					Image newImg=img.getScaledInstance(label_1.getWidth(),label_1.getHeight(),Image.SCALE_SMOOTH);
					ImageIcon finalImg=new ImageIcon(newImg);
					label_1.setIcon(finalImg);
					pathh=path;
				}
				
			}
		});
		button_4.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\look.PNG"));
		button_4.setBounds(286, 288, 34, 37);
		contentPane.add(button_4);
		
		JLabel lblAffiche = new JLabel("affiche:");
		lblAffiche.setBounds(10, 213, 48, 14);
		contentPane.add(lblAffiche);
		
		dateField = new JTextField();
		dateField.setBounds(122, 154, 198, 20);
		contentPane.add(dateField);
		dateField.setColumns(10);
		
		JButton button_5 = new JButton("");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			MainMenu ma=new MainMenu();
			ma.setVisible(true);
			close();
			}
		});
		button_5.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\backkk.PNG"));
		button_5.setBounds(0, 42, 42, 30);
		contentPane.add(button_5);
	}
	public void actualiserTable() {
	String sql="select * from events";
	try {
		PreparedStatement stmt=conx.prepareStatement(sql);
		ResultSet result=stmt.executeQuery();
		table.setModel(DbUtils.resultSetToTableModel(result));
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
