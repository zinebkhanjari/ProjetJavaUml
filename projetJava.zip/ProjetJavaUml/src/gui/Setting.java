package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.PreparedStatement;

import Dao.ConnectionDataBase;
import metier.Adherent;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Setting extends JFrame {

	private JPanel contentPane;
	 String email;
	private JTextField nomField;
	private JTextField prenomField;
	private JTextField emailField;
	private JTextField telField;
	private JTextField passwordField;
	
 Connection conx;
 JComboBox comboBox;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Setting frame = new Setting();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Setting( ) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100,774,651);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button_1 = new JButton("");
		button_1.setBackground(Color.WHITE);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateData();
			}
		});
		button_1.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGqqqqqqq.PNG"));
		button_1.setBounds(583, 110, 50, 45);
		contentPane.add(button_1);
		
		nomField = new JTextField();
		nomField.setBackground(Color.CYAN);
		nomField.setBounds(307, 189, 241, 20);
		contentPane.add(nomField);
		nomField.setColumns(10);
		
		
		prenomField = new JTextField();
		prenomField.setColumns(10);
		prenomField.setBackground(Color.CYAN);
		prenomField.setBounds(307, 244, 241, 20);
		contentPane.add(prenomField);
		
		try {
			conx=ConnectionDataBase.connectionBd();
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBackground(Color.CYAN);
		emailField.setBounds(307, 128, 241, 20);
		contentPane.add(emailField);
		//email=Adherent.getEmailAd();
		//System.out.println(email);
		//System.out.println(Adherent.getEmailAd());
		
		telField = new JTextField();
		telField.setColumns(10);
		telField.setBackground(Color.CYAN);
		telField.setBounds(307, 299, 241, 20);
		contentPane.add(telField);
		
		passwordField = new JTextField();
		passwordField.setColumns(10);
		passwordField.setBackground(Color.CYAN);
		passwordField.setBounds(307, 426, 241, 20);
		contentPane.add(passwordField);
		
		comboBox = new JComboBox();
		comboBox.setBackground(Color.CYAN);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"2ITE-1", "2ITE-2", "ISIC-1", "ISIC-2"}));
		comboBox.setBounds(304, 361, 244, 22);
		contentPane.add(comboBox);
		
		JLabel lblEmail = new JLabel("email:");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblEmail.setBounds(171, 131, 377, 14);
		contentPane.add(lblEmail);
		
		JLabel lblNom = new JLabel("nom:");
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNom.setBounds(171, 192, 377, 14);
		contentPane.add(lblNom);
		
		JLabel lblPrenom = new JLabel("prenom:");
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblPrenom.setBounds(171, 246, 377, 14);
		contentPane.add(lblPrenom);
		
		JLabel lblTlphone = new JLabel("t\u00E9l\u00E9phone:");
		lblTlphone.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTlphone.setBounds(171, 302, 377, 14);
		contentPane.add(lblTlphone);
		
		JLabel lblNiveau = new JLabel("niveau:");
		lblNiveau.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNiveau.setBounds(171, 365, 377, 14);
		contentPane.add(lblNiveau);
		
		JLabel lblMotDePasse = new JLabel("mot de passe:");
		lblMotDePasse.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMotDePasse.setBounds(171, 429, 377, 14);
		contentPane.add(lblMotDePasse);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
		label.setBounds(316, 0, 133, 117);
		contentPane.add(label);
		
		JLabel lblModifier = new JLabel("modifier");
		lblModifier.setBounds(398, 587, 66, 14);
		contentPane.add(lblModifier);
		
		JLabel lblChargerMesInformations = new JLabel("charger mes informations ");
		lblChargerMesInformations.setBounds(571, 158, 133, 14);
		contentPane.add(lblChargerMesInformations);
		
		JButton buttonlast = new JButton("");
		
		buttonlast.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGjjjj.PNG"));
		buttonlast.setBounds(373, 494, 89, 53);
		contentPane.add(buttonlast);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\backkk.PNG"));
		button.setBounds(27, 110, 50, 45);
		contentPane.add(button);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdherentMenu ad=new AdherentMenu();
				ad.setVisible(true);
				dispose();
			}
		});

		
		}
	public Setting(String email) throws HeadlessException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,774,651);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button_1 = new JButton("");
		button_1.setBackground(Color.WHITE);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateData();
			}
		});
		button_1.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGqqqqqqq.PNG"));
		button_1.setBounds(583, 110, 50, 45);
		contentPane.add(button_1);
		
		nomField = new JTextField();
		nomField.setBackground(Color.CYAN);
		nomField.setBounds(307, 189, 241, 20);
		contentPane.add(nomField);
		nomField.setColumns(10);
		
		
		prenomField = new JTextField();
		prenomField.setColumns(10);
		prenomField.setBackground(Color.CYAN);
		prenomField.setBounds(307, 244, 241, 20);
		contentPane.add(prenomField);
		
		try {
			conx=ConnectionDataBase.connectionBd();
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBackground(Color.CYAN);
		emailField.setBounds(307, 128, 241, 20);
		contentPane.add(emailField);
		//email=Adherent.getEmailAd();
		//System.out.println(email);
		//System.out.println(Adherent.getEmailAd());
		
		telField = new JTextField();
		telField.setColumns(10);
		telField.setBackground(Color.CYAN);
		telField.setBounds(307, 299, 241, 20);
		contentPane.add(telField);
		
		passwordField = new JTextField();
		passwordField.setColumns(10);
		passwordField.setBackground(Color.CYAN);
		passwordField.setBounds(307, 426, 241, 20);
		contentPane.add(passwordField);
		
		comboBox = new JComboBox();
		comboBox.setBackground(Color.CYAN);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"2ITE-1", "2ITE-2", "ISIC-1", "ISIC-2"}));
		comboBox.setBounds(304, 361, 244, 22);
		contentPane.add(comboBox);
		
		JLabel lblEmail = new JLabel("email:");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblEmail.setBounds(171, 131, 377, 14);
		contentPane.add(lblEmail);
		
		JLabel lblNom = new JLabel("nom:");
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNom.setBounds(171, 192, 377, 14);
		contentPane.add(lblNom);
		
		JLabel lblPrenom = new JLabel("prenom:");
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblPrenom.setBounds(171, 246, 377, 14);
		contentPane.add(lblPrenom);
		
		JLabel lblTlphone = new JLabel("t\u00E9l\u00E9phone:");
		lblTlphone.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTlphone.setBounds(171, 302, 377, 14);
		contentPane.add(lblTlphone);
		
		JLabel lblNiveau = new JLabel("niveau:");
		lblNiveau.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNiveau.setBounds(171, 365, 377, 14);
		contentPane.add(lblNiveau);
		
		JLabel lblMotDePasse = new JLabel("mot de passe:");
		lblMotDePasse.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMotDePasse.setBounds(171, 429, 377, 14);
		contentPane.add(lblMotDePasse);
		emailField.setEditable(false);
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
		label.setBounds(316, 0, 133, 117);
		contentPane.add(label);
		JLabel lblChargerMesInformations = new JLabel("charger mes informations ");
		lblChargerMesInformations.setBounds(571, 158, 133, 14);
		contentPane.add(lblChargerMesInformations);
		
		JButton buttonlast = new JButton("");
		buttonlast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateData();
			}
		});
		buttonlast.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNGjjjj.PNG"));
		buttonlast.setBounds(373, 494, 89, 53);
		buttonlast.setBackground(Color.WHITE);
		contentPane.add(buttonlast);
		buttonlast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				java.sql.PreparedStatement myStmt=null;
				String email=emailField.getText();
				String nom=nomField.getText();
				String prenom=prenomField.getText();
				String tel=telField.getText();
				String niveau=comboBox.getSelectedItem().toString();
				try {
					myStmt=conx.prepareStatement("update adherent set nomAd=?,prenomAd=?,telAd=?,niveauAd=? where emailAd=?");
					myStmt.setString(1, nom);
					myStmt.setString(2, prenom);
					myStmt.setString(3, tel);
					myStmt.setString(4, niveau);
					myStmt.setString(5, email);
					myStmt.executeUpdate();
					JOptionPane.showMessageDialog(null, "modification r�ussite");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	
		this.email = email;
		System.out.println("this is real "+email);
	}

	/*public Setting(String email) throws HeadlessException {
		super();
		System.out.println("kqsldj"+email);
		PreparedStatement stmt=null;
		ResultSet result=null;
		emailField.setText(email.toString());
		String email1=emailField.getText();
		
		try {
			stmt=(PreparedStatement) conx.prepareStatement("select nomAd,prenomAd,telAd,niveauAd,password from adherent where emailAd=?");
			stmt.setString(1, email1);
			result=stmt.executeQuery();
			while(result.next()) {
				String nom=result.getString("nomAd").toString();
				String prenom=result.getString("prenomAd").toString();
				String tel=result.getString("telAd").toString();
				String niveau=result.getString("nomAd").toString();
		
				nomField.setText(nom);
				prenomField.setText(prenom);
				telField.setText(tel);
				comboBox.setSelectedItem(niveau);
				
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
*/
	public void updateData() {
		PreparedStatement stmt=null;
		ResultSet result=null;
		
		
		try {
			stmt=(PreparedStatement) conx.prepareStatement("select nomAd,prenomAd,telAd,niveauAd,password from adherent where emailAd=?");
			stmt.setString(1, email);
			result=stmt.executeQuery();
			while(result.next()) {
				String nom=result.getString("nomAd").toString();
				String prenom=result.getString("prenomAd").toString();
				String tel=result.getString("telAd").toString();
				String niveau=result.getString("niveauAd").toString();
				String pass=result.getString("password").toString();
				
				emailField.setText(email);
				emailField.setEditable(false);
				nomField.setText(nom);
				prenomField.setText(prenom);
				telField.setText(tel);
				comboBox.setSelectedItem(niveau);
				passwordField.setText(pass);
				
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   
	}
}
