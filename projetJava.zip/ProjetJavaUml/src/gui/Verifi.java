package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Dao.ConnectionDataBase;
import metier.Adherent;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;


public class Verifi extends JFrame {

	private JPanel contentPane;
	private JTextField emailField;
	private JPasswordField passwordField;
	private JLabel lblVerifierVosInformations;
	Connection conx ;
	
static String email1;
String pass1;
String nom;
String prenom;
boolean connect�;
private JButton btnNewButton;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Profile frame = new Profile();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Verifi() {
		setTitle("V\u00E9rification des infos");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		emailField = new JTextField();
		emailField.setBackground(Color.CYAN);
		emailField.setBounds(136, 69, 126, 20);
		contentPane.add(emailField);
		emailField.setColumns(10);
		
		
		JLabel lblEmail = new JLabel("email:");
		lblEmail.setBounds(23, 72, 48, 14);
		contentPane.add(lblEmail);
		
		
		JLabel lblMotDePasse = new JLabel("mot de passe:");
		lblMotDePasse.setBounds(23, 130, 103, 14);
		contentPane.add(lblMotDePasse);
		try {
			conx=ConnectionDataBase.connectionBd();
		} catch (ClassNotFoundException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		
		JButton btnOk = new JButton("ok");
		btnOk.addActionListener(new ActionListener() {
			@SuppressWarnings("null")
			public void actionPerformed(ActionEvent e) {
				
				String email=emailField.getText();
				String password=passwordField.getText();
				ResultSet result=null;
				PreparedStatement myStmt = null;
				try {
					myStmt=conx.prepareStatement("select * from adherent");
					result=myStmt.executeQuery();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				if(email.equals("") || password.equals("")) {
					JOptionPane.showMessageDialog(null, "entrer vos cordon�es");
				}
				else
				{

					try {
						while(result.next()) {
					    email1=result.getString("emailAd");
						 pass1=result.getString("password");
						 nom=result.getString("nomAd");
						 prenom=result.getString("prenomAd");
						}}
						 catch (HeadlessException | SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						
						if(email1.equals(email) && pass1.equals(password)) {
							
							
							connect�=true;
							
							String nomAb=nom+" "+prenom;
							System.out.println(nomAb);
						AbsConsult ab=new AbsConsult(nomAb);
						ab.setVisible(true);
						dispose();
							
						}
					  
						if (!connect�) {
							JOptionPane.showMessageDialog(null, "connection �chou�");
							emailField.setText("");
							passwordField.setText("");
							
						}}
				
				
			}
		});
		btnOk.setBounds(81, 198, 89, 23);
		contentPane.add(btnOk);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(Color.CYAN);
		passwordField.setBounds(136, 127, 126, 20);
		contentPane.add(passwordField);
		
		lblVerifierVosInformations = new JLabel("");
		lblVerifierVosInformations.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\projetJava\\Capture.PNG"));
		lblVerifierVosInformations.setBounds(298, 69, 126, 106);
		contentPane.add(lblVerifierVosInformations);
		
		btnNewButton = new JButton("annuler");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdherentMenu ad=new AdherentMenu();
				ad.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(208, 198, 89, 23);
		contentPane.add(btnNewButton);
	}
}
